# Dashboard Preview Image for the above project.


<img width="1354" alt="Dashboard Image" src="https://github.com/ritesh-29/data-analysis-excel/assets/27215092/168c2bea-e041-4b59-a4ab-977bd3d88e33">
